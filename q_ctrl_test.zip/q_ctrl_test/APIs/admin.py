from django.contrib import admin
from .models import pulses

# Register your models here.
admin.site.register(pulses)
