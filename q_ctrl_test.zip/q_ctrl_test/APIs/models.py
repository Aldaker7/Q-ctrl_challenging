from django.db import models
from django.core.validators import MaxValueValidator

# Create your models here.
class pulses(models.Model):
    name = models.CharField(max_length=120)
    pulses_type = [
        ('Primitive','Primitive'),
        ('CORPSE','CORPSE'),
        ('Gaussian','Gaussian'),
        ('CinBB','CinBB '),
        ('CinSK','CinSK')
    ]
    types = models.CharField(max_length=10,
                            choices=pulses_type,
                             default='Primitive')
    max_rb_rate = models.PositiveIntegerField(validators=[MaxValueValidator(100)])
    polar_angle = models.PositiveIntegerField(validators=[MaxValueValidator(1)])

    def __str__(self):
        return self.name
