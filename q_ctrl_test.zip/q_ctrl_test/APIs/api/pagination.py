from rest_framework.pagination import (LimitOffsetPagination)


# to make the limit each page is 5 results
class PulseLimitPagination(LimitOffsetPagination):
    default_limit = 5
    max_limit = 5