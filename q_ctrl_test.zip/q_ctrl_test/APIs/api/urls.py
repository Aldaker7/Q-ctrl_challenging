from django.urls import path,re_path

from .views import (PulseListAPIView,PulseDetailAPIView,
                    PulseDestroyAPIView,
                    PulseCreateAPIView,upload_csv,download_csv)

urlpatterns = [
    path('', PulseListAPIView.as_view(),name='ListView'),
    re_path(r'^pulse/detail/(?P<pk>\d+)$',PulseDetailAPIView.as_view(),name='DetailView'),
    re_path(r'^pulse/delete/(?P<pk>\d+)$',PulseDestroyAPIView.as_view(),name='DestroyView'),
    re_path(r'^pulse/create/$',PulseCreateAPIView.as_view(),name='CreateView'),
    re_path(r'^upload/csv/',upload_csv,name='upload_csv'),
    re_path(r'^download/csv/',download_csv,name='download_csv'),
]
