from django.db.models import Q
from rest_framework.generics import (ListAPIView,RetrieveAPIView,
                                     UpdateAPIView,DestroyAPIView,
                                     CreateAPIView,RetrieveUpdateAPIView,)
from APIs.models import pulses
from .serializer import PulseSerializer
from django.contrib import messages
from .pagination import PulseLimitPagination
from django.shortcuts import render
from django.http import HttpResponse, HttpResponseRedirect
from django.urls import reverse
import requests, json, csv, os

#This the API class for listing all results
class PulseListAPIView(ListAPIView):
    serializer_class = PulseSerializer
    #calling the class to make the results limit for 5 ep
    pagination_class = PulseLimitPagination

    #overriding the queryset method to make it accept search
    def get_queryset(self,*args,**kwargs):
        queryset_list = pulses.objects.all()
        query = self.request.GET.get("q")
        if query:
            #filtiring based on all fields created in the model
            queryset_list = queryset_list.filter(
                Q(name__icontains=query)|
                Q(types__icontains=query)|
                Q(max_rb_rate__icontains=query)|
                Q(polar_angle__icontains=query))

        return queryset_list

#This the API class for retrieving and updating specific result
class PulseDetailAPIView(RetrieveUpdateAPIView):
    queryset = pulses.objects.all()
    serializer_class = PulseSerializer

#This the API class for Deletign specific result
class PulseDestroyAPIView(DestroyAPIView):
    queryset = pulses.objects.all()
    serializer_class = PulseSerializer

#This the API class for creating new result
class PulseCreateAPIView(CreateAPIView):
    queryset = pulses.objects.all()
    serializer_class = PulseSerializer

def upload_csv(request):

    data = {}
    print(request.method)
    if request.method == 'GET':
        return render(request,'upload_csv.html',data)
    csv_file = request.FILES["csv_file"]
    if not csv_file.name.endswith('.csv'):
        messages.error(request, 'File is not CSV type')
        return HttpResponse(reverse('upload_csv'))
    file_data = csv_file.read().decode("utf-8")
    data_lst = []
    count = 0
    lines = (file_data.split('\n'))

    for line in lines:
        count+=1
        data_line = {}
        print(line,count)
        fields = line.split(',')
#        print(type(fields[2]),type(fields[3]))
        if fields[1] not in ['Primitive','CORPSE','Gaussian','CinBB ','CinSK']:
            return HttpResponse("Types are not as predifined please correct the CSV in line %s"%count)
        elif int(fields[2]) >100 and int(fields[2]) < 0:
            return HttpResponse("Max rb rate are either greater than 100 or less than 0 the CSV in line %s"%count)
        elif int(fields[3]) not in [0,1]:
            return HttpResponse("Polar Angle is not in the range of [0,1] in  the CSV in line %s" % count)
        else:
            data_line.update({'name':fields[0],'types':fields[1],
                              'max_rb_rate':(fields[2]),'polar_angle':int(fields[3])
                              })
            #Calling post api to insert rows into DB
            r = requests.post('http://localhost:8000/api/pulse/create/',
                              headers={'content-type': 'application/json'},
                              data=json.dumps({'name':fields[0],'types':fields[1],
                              'max_rb_rate':(fields[2]),'polar_angle':int(fields[3])}))
            if r.status_code not in [200,201]:
                return HttpResponse("<h2>Oops Error:%s</h2>"%str(r.status_code))
    return HttpResponse("<h2 style='color:green'>Your CSV file has been inserted into DB sccessfully!</h2>")

#Downloading CSV to your wroking directory/pulses.csv
def download_csv(request):
    if request.method == 'POST':
        #calling get API to retrieve all data to insert it into CSV
        r = requests.get('http://localhost:8000/api/',headers={'content-type': 'application/json'})
        if r.status_code == 200:
            data = r.json().get('results')
            while r.json().get('next') != None:
                r = requests.get(r.json().get('next'))
                data += r.json().get('results')
        if data:
            dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
            with open(dir+'/pulses.csv', 'w') as writeFile:
                writer = csv.writer(writeFile)
                for i in data:
                    row = {str(i['name'])+','+str(i['types'])+','+str(i['max_rb_rate'])+','+str(i['polar_angle'])}
                    writer.writerows([row])
            writeFile.close()
            return HttpResponse("<h2 style='color:green'>Your CSV file is downloaded at: </h2><br>%s"%(dir+'/pulses.csv'))
        else:
            return HttpResponse("<h2 style='color:red'> Oops there is not data to create your CSV file </h2>")
    else:
        return render(request,'download_csv.html',{})

#to make you able to search on data from homepage instead of using the url
def search_pulse(request):
    if request.method == "POST":
        return HttpResponseRedirect('http://localhost:8000/api/?q=%s'%str(request.POST['search']))
    else:
        return render(request,'home.html',{})

