from rest_framework import serializers
from APIs.models import pulses

#creating The Django rest API framework form
class PulseSerializer(serializers.ModelSerializer):

    class Meta:
        model = pulses
        fields = '__all__'#to show all fields in the form
